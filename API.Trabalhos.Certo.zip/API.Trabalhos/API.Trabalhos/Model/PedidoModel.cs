﻿
namespace API.Trabalho.Model
{
    public class PedidosModel
    {
        public int Id { get; set; }
        public string EnderecoEntrega { get; set; }
        public int? UsuarioId { get; set; }
        public virtual UsuariosModel? Usuario { get; set; }
    }
}