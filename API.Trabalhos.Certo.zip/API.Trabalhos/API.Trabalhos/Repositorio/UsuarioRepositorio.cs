﻿using Microsoft.EntityFrameworkCore;
using API.Trabalho.Data;
using API.Trabalho.Model;
using API.Trabalho.Repositorio.Interface;

namespace API.Trabalho.Repositorio
{
    public class UsuarioRepositorio : IUsuarioRepositorio
    {
        private readonly CauaDbContext _dbContext;

        public UsuarioRepositorio(CauaDbContext avaliacaoDbContext)
        {
            _dbContext = avaliacaoDbContext;
        }

        public async Task<UsuariosModel> BuscarPorId(int id)
        {
            return await _dbContext.Usuarios.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<UsuariosModel>> BuscarTodosUsuarios()
        {
            return await _dbContext.Usuarios.ToListAsync();
        }
        public async Task<UsuariosModel> Adicionar(UsuariosModel usuario)
        {
            await _dbContext.Usuarios.AddAsync(usuario);
            await _dbContext.SaveChangesAsync();

            return usuario;
        }
        public async Task<UsuariosModel> Atualizar(UsuariosModel usuario, int id)
        {
            UsuariosModel usuariorPorId = await BuscarPorId(id);
            if (usuariorPorId == null)
            {
                throw new Exception($"Usuario do ID: {id} nao foi encontrado");
            }
            usuariorPorId.Nome = usuario.Nome;
            usuariorPorId.Email = usuario.Email;
            usuariorPorId.DataNascimento = usuario.DataNascimento;

            _dbContext.Usuarios.Update(usuariorPorId);
            await _dbContext.SaveChangesAsync();
            return usuariorPorId;
        }

        public async Task<bool> Apagar(int id)
        {
            UsuariosModel usuariorPorId = await BuscarPorId(id);
            if (usuariorPorId == null)
            {
                throw new Exception("Usuarios nao encontrado");
            }
            _dbContext.Usuarios.Remove(usuariorPorId);
            await _dbContext.SaveChangesAsync();

            return true;
        }
    }
}
