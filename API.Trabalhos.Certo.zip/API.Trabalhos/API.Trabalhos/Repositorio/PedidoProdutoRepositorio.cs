﻿using Microsoft.EntityFrameworkCore;
using API.Trabalho.Data;
using API.Trabalho.Model;
using API.Trabalho.Repositorio.Interface;

namespace API.Trabalho.Repositorio
{
    public class PedidoProdutoRepositorio : IPedidoProdutoRepositorio
    {
        private readonly CauaDbContext _dbContext;

        public PedidoProdutoRepositorio(CauaDbContext avaliacaoDbContext)
        {
            _dbContext = avaliacaoDbContext;
        }

        public async Task<PedidoProdutoModel> BuscarPorId(int id)
        {
            return await _dbContext.PedidosProduto
                .Include(x => x.ProdutoId)
                .FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<PedidoProdutoModel>> BuscarTodosProdutosPedido()
        {
            return await _dbContext.PedidosProduto
                .Include(x => x.Produto)
                .ToListAsync();
        }
        public async Task<PedidoProdutoModel> Adicionar(PedidoProdutoModel PedidoProduto)
        {
            await _dbContext.PedidosProduto.AddAsync(PedidoProduto);
            await _dbContext.SaveChangesAsync();

            return PedidoProduto;
        }
        public async Task<PedidoProdutoModel> Atualizar(PedidoProdutoModel PedidoProduto, int id)
        {
            PedidoProdutoModel PedidoProdutoPorId = await BuscarPorId(id);
            if (PedidoProdutoPorId == null)
            {
                throw new Exception($"Quantidade do ID: {id} nao foi encontrado");
            }
            PedidoProdutoPorId.quantidade = PedidoProduto.quantidade;





            _dbContext.PedidosProduto.Update(PedidoProdutoPorId);
            await _dbContext.SaveChangesAsync();
            return PedidoProdutoPorId;
        }

        public async Task<bool> Apagar(int id)
        {
            PedidoProdutoModel PedidoProdutoPorId = await BuscarPorId(id);
            if (PedidoProdutoPorId == null)
            {
                throw new Exception("PedidoProduto nao encontrados");
            }
            _dbContext.PedidosProduto.Remove(PedidoProdutoPorId);
            await _dbContext.SaveChangesAsync();

            return true;
        }

        
    }
}

