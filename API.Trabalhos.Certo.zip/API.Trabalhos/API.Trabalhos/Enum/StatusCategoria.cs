﻿using System.ComponentModel;

namespace API.Trabalho.Enum
{
    public enum StatusCategoria
    {
        [Description("Ativo")]
        Ativo = 1,
        [Description("Inativo")]
        Inativo = 2,

    }
}