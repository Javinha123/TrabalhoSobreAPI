﻿using API.Trabalho.Model;
using API.Trabalho.Repositorio.Interface;
using Microsoft.AspNetCore.Mvc;

namespace API.Trabalho.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        private readonly IUsuarioRepositorio _usuariosRepositorio;
        public UsuarioController(IUsuarioRepositorio usuaarioRepositorio)
        {
            _usuariosRepositorio = usuaarioRepositorio;
        }
        [HttpGet]
        public async Task<ActionResult<List<UsuariosModel>>> BuscarTodosUsuarios()
        {
            List<UsuariosModel> usuarios = await _usuariosRepositorio.BuscarTodosUsuarios();
            return Ok(usuarios);
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<UsuariosModel>> BuscarPorId(int id)
        {
            UsuariosModel usuario = await _usuariosRepositorio.BuscarPorId(id);
            return Ok(usuario);
        }
        [HttpPost]
        public async Task<ActionResult<UsuariosModel>> Adicionar([FromBody] UsuariosModel usuarioModel)
        {
            UsuariosModel usuario = await _usuariosRepositorio.Adicionar(usuarioModel);
            return Ok(usuario);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult<UsuariosModel>> Atualizar(int id, [FromBody] UsuariosModel usuarioModel)
        {
            usuarioModel.Id = id;
            UsuariosModel usuario = await _usuariosRepositorio.Atualizar(usuarioModel, id);
            return Ok(usuario);
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult<UsuariosModel>> Apagar(int id)
        {
            bool apagado = await _usuariosRepositorio.Apagar(id);
            return Ok(apagado);
        }
    }
}
